function showNews() {
    var x = document.getElementById("hidden_news");
    x.style.display = "block";
    var x = document.getElementById("hide_news_botton");
    x.style.display = "none";
}

function showEvents() {
    var x = document.getElementById("hidden_events");
    x.style.display = "block";
    var x = document.getElementById("hide_events_botton");
    x.style.display = "none";
}